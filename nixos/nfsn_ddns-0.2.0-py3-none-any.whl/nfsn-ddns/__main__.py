# SPDX-License-Identifier: BSD-2-Clause
# Copyright nfsn-ddns Contributors

from nfsn_ddns.__main__ import main
import sys

if __name__ == '__main__':
    sys.exit(main())
