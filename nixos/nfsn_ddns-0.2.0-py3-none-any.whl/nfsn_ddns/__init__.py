# SPDX-License-Identifier: BSD-2-Clause
# Copyright nfsn-ddns Contributors

__version__ = '0.2.0'
